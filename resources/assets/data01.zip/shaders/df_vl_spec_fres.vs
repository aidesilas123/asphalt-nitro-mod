uniform highp mat4 inWorldMatrix;
uniform highp mat4 inWorldViewProjMatrix;
uniform highp mat4 inWorldViewMatrixT;

uniform highp int inPLightCount;
uniform highp vec3 inPLightPos[MAX_LIGHTS];
uniform highp vec3 inCameraPos;

#ifdef USE_FOG
uniform lowp vec4 fogColor;
uniform highp float fogStart;
uniform highp float fogRangeI;
varying lowp float fogFactor;
#endif

attribute vec4 inPos;
attribute vec4 inNormal;
attribute vec2 inUV0;

varying lowp vec3 normal;
varying lowp vec3 lightDir;
varying lowp vec3 eyeDir;
varying highp vec2 uv;

#ifdef COMPUTE_LINEAR_DEPTH
	varying highp vec3 positionWorldSpace;
#endif

void main()
{
	{
		highp float vertDepth = dot(inWorldViewMatrixT[2], vec4(inPos.xyz, 1.0));
#ifdef USE_FOG
		lowp float fog = clamp((-vertDepth-fogStart) * fogRangeI, 0.0, 1.0);
		fogFactor = fog * fogColor.a;
#endif
	}
	gl_Position = inWorldViewProjMatrix * vec4(inPos.xyz, 1.0);
	highp vec3 pos = inPos.xyz;

	lightDir = normalize(inPLightPos[0] - pos);
	eyeDir = normalize(inCameraPos - pos);
	normal = inNormal.xyz;

	uv.xy = inUV0;
	
#ifdef COMPUTE_LINEAR_DEPTH
	highp vec4 posWS = (inWorldMatrix * vec4(inPos.xyz, 1.0));
	positionWorldSpace = posWS.xyz;
#endif
}
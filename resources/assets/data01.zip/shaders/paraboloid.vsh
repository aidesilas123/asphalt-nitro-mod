highp vec2 GetSingleParaboloidReflectionUV(highp vec3 reflectionVector)
{
	highp vec4 d = vec4(0.0,0.0,1.0,0.0);
	highp vec3 finalCoord = reflectionVector;
	finalCoord += d.xyz;
	finalCoord.xy /= finalCoord.z;
	finalCoord.xy = finalCoord.xy*0.5 + 0.5;
	return finalCoord.xy;
}
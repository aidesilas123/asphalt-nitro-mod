/*
----------------------------------------------------------
Ubershader usable parameters:
-----------------------------
Guide:
   + 	: optional parameter (the previous one should be added first). Only one of this optional params can be adde per each property.
   ++ 	: mandatory parameter (must be added if the previous one is added first). Only one of this optional params can be adde per each property.
   -or-	: exclusive parameter (if the element it's added noone of the similar/neighbour params can be added)
----------------------------------------------------------
	
USE_BARLA -> the diffuse-light calculation is done with a barla palette (Fx_BARLA_xxxxx.tga) 

USE_EMISSIVENESS -> the G channel of the MK texture is the mask for the emissiven (self illuminated) parts of the object

USE_SPECULARLIGHT -> adds specular light to the object
	++ USE_SPECULARLIGHT0 -> specPerLight (specular computed per light position + specularGlossiness)
	++ USE_SPECULARLIGHT1 -> specPalettePerLight (specular computed per light position + specularPalette [Fx_SPEC_xxxxx.tga])
	++ USE_SPECULARLIGHT2 -> specPerView (specular computed per camera + specularGlossiness)
	++ USE_SPECULARLIGHT3 -> specPalettePerView (specular computed per camera + specularPalette [Fx_SPEC_xxxxx.tga])

USE_LINEARSPACE -> corrects the SPECULAR calculation to linear-space (pow 0.45). the diffuse calculation si done with the barla palette, so it can be customized to emulate the gamma 2.2.
	
USE_RIMLIGHT -> adds per vertex rimlight.

USE_NDIS -> adds the NDIS texture as specular (thid means: additive over the diffuse). If there is specualr too, both are added.
 -or-
USE_NDISREFLECTION -> adds the NDIS texture as reflection (thid means: mix over the diffuse).
	+ USE_NDISALPHA -> adds (+) the NDIS.r channel to the DF alpha value. This makes the NDIS hilights opaque.
	+ USE_NDISGLASSEFFECT -> adds (+) the (NDIS.r * NDIS.g) to the DF alpha value. This makes the NDIS hilights opaque. 

USE_STAIN -> multiply a texture over the current final complete.
	
USE_ANIMATEDOVERLAY -> adds an animated overlay over the complete final color (the overlay is applied with additive blend).

USE_ANIMATEDTEXTURE -> all the 3 texture samplers (DF,NM,MK) are animated with offsets.

USE_VERTEXLIGHT -> use vertex lighting calculated with a maximum of 5 simultaneous lights. (The ligh is applied with additive)

USE_VERTEXDISTORTION -> shift the vertex positions using the vertex color as modulator.

----------------------------------------------------------
Define parameters:
----------------------------------------------------------
#define USE_VFOG 					//<-- optional for [USE_FOG]
#define USE_BARLA
#define USE_EMISSIVENESS
#define USE_SPECULARLIGHT
#define USE_SPECULARLIGHT0			//<-- mandatory for [USE_SPECULARLIGHT]
	//#define USE_SPECULARLIGHT1	//<-- mandatory for [USE_SPECULARLIGHT]
	//#define USE_SPECULARLIGHT2	//<-- mandatory for [USE_SPECULARLIGHT]
	//#define USE_SPECULARLIGHT3	//<-- mandatory for [USE_SPECULARLIGHT]	
#define USE_LINEARSPACE
#define USE_RIMLIGHT
#define USE_NDIS					//<-- exclusive between [USE_NDIS] & [USE_NDISREFLECTION]
	//#define USE_NDISREFLECTION	//<-- exclusive between [USE_NDIS] & [USE_NDISREFLECTION]	
	//#define USE_NDISALPHA			//<-- optional for [USE_NDIS] or [USE_NDISREFLECTION]	
	//#define USE_NDISGLASSEFFECT	//<-- optional for [USE_NDIS] or [USE_NDISREFLECTION]	
	//#define USE_ANIMATEDOVERLAY
	//#define USE_ANIMATEDTEXTURE
#define USE_STAIN
#define USE_VERTEXLIGHT
	//#define USE_VERTEXDISTORTION

*/


uniform highp mat4 inWorldViewProjMatrix;		
uniform highp mat4 inWorldMatrix;


attribute vec4 inPos;
attribute vec2 inUV0;

varying highp	vec2 uv0;

#if defined(USE_VERTEXDISTORTION) || defined(USE_ANIMATEDTEXTURE) || defined(USE_ANIMATEDOVERLAY)
	uniform highp float fracTime;
#endif

#if defined(USE_VERTEXDISTORTION)
	attribute vec4 inColors;
	uniform	highp vec3 V_speed;
	uniform	highp vec3 V_amplitude;
	uniform	highp vec3 V_offset;
#endif

#if defined(USE_BARLA) || defined(USE_RIMLIGHT) || defined(USE_VERTEXLIGHT) || defined(USE_SPECULARLIGHT) || defined(USE_NDIS) || defined(USE_NDISREFLECTION)
	attribute vec4 inNormal;
#endif

#if defined(USE_BARLA) || defined(USE_RIMLIGHT) || defined(USE_VERTEXLIGHT) || defined(USE_SPECULARLIGHT)
	attribute vec4 inTangent;
#endif

#if defined(USE_NDIS) || defined(USE_NDISREFLECTION)
	uniform highp float reflectionBend;
	uniform highp mat4 inWorldViewITMatrix;
	varying highp 	vec3  VSN;
#endif

#if defined(USE_ANIMATEDTEXTURE) || defined(USE_ANIMATEDOVERLAY)
	uniform highp float X_speed;
	uniform highp float Y_speed;
#endif

#if defined(USE_ANIMATEDOVERLAY)
	varying highp	vec2 uvOverlay;
#endif

#if defined(USE_VFOG)
	uniform	mediump float 	inFogHeigh;
#endif

#ifdef USE_FOG
	uniform	mediump float 		inFogStart;
	uniform	mediump float 		inFogRangeI;
	uniform lowp 	vec4 		inFogColor;				
	varying lowp 	float 		fogRatio;
#endif

#if defined(USE_BARLA) || defined(USE_SPECULARLIGHT) || defined(USE_VERTEXLIGHT)
	uniform highp 	vec3 inPLightPos[8];
#endif

#if defined(USE_BARLA) || defined(USE_SPECULARLIGHT) || defined(USE_RIMLIGHT) 
	varying lowp 	vec3 LightDirection;					
#endif

#if defined(USE_SPECULARLIGHT) || defined(USE_RIMLIGHT)
	uniform highp 	vec3 inCameraPosOS;
	varying lowp 	vec3 ViewDirection;
#endif

#if defined(USE_SPECULARLIGHT0) || defined(USE_SPECULARLIGHT1)
	varying lowp 	vec3 H;
#endif

#ifdef USE_RIMLIGHT
	uniform mediump 	float edgeIntensity;
	uniform mediump 	float edgeGlossy;
	varying mediump 	float Rim;
#endif

#ifdef USE_VERTEXLIGHT
	uniform lowp 		vec3 	lightDiffuse[5];
	uniform mediump 	float 	lightRadius[5];
	varying lowp 	vec4	VXL;
#endif

#ifdef COMPUTE_LINEAR_DEPTH
	varying highp vec3 positionWorldSpace;
#endif

void main()
{
	highp vec4 vPos = inPos;
	
	#if defined(USE_VERTEXDISTORTION)
		lowp vec3 vc = inColors.rgr;
		vc.b = (vc.r+vc.g)*0.5;

		highp vec3 vcShift = (vec3(sin(fracTime * V_speed)) * V_amplitude * vc) + (V_offset * vc);
		highp float vcShiftB = ((sin(fracTime * V_speed.b)) * V_amplitude.b * vc.b) + (V_offset.b * vc.b);
		vcShift.g = vcShift.g - vcShiftB;
		vPos = vPos + vec4(vcShift,0.0); 
	#endif

	gl_Position = inWorldViewProjMatrix * vec4(inPos.xyz, 1.0);
	
	uv0    = inUV0;
	
	#if defined(USE_ANIMATEDTEXTURE) || defined(USE_ANIMATEDOVERLAY)
		highp vec2 uvOffset = vec2(fracTime * X_speed, fracTime * Y_speed);
	#endif
	
	#if defined(USE_ANIMATEDTEXTURE)
		uv0 += uvOffset;
	#endif

	#if defined(USE_ANIMATEDOVERLAY)
		uvOverlay = uv0 + uvOffset;
	#endif
	
	#if defined(USE_NDIS) || defined(USE_NDISREFLECTION)
		highp vec2 fragPos 	= normalize(gl_Position.xyz).xy;
		
		VSN 	= (inWorldViewITMatrix *  vec4(inNormal.xyz, 0.0)).xyz;
		VSN 	= normalize(VSN) * 0.5 + 0.5;
		VSN.xy 	+= fragPos * reflectionBend ;
	#endif
	
	#if defined(USE_BARLA) || defined(USE_RIMLIGHT) || defined(USE_VERTEXLIGHT) || defined(USE_SPECULARLIGHT)
		highp vec3 Normal   = normalize(inNormal.xyz);
		highp vec3 Tangent  = normalize(inTangent.xyz);
		highp vec3 Binormal = cross(Normal, Tangent) * -inTangent.w;
	#endif

	#if defined(USE_SPECULARLIGHT2) || defined(USE_SPECULARLIGHT3) || defined(USE_SPECULARLIGHT0) ||  defined(USE_SPECULARLIGHT1) ||  defined(USE_RIMLIGHT)
		highp vec3 ViewDir  = normalize(inCameraPosOS - vPos.xyz);
	#endif
	
	#if defined(USE_SPECULARLIGHT2) || defined(USE_SPECULARLIGHT3) 
		ViewDirection.x = dot( Tangent, ViewDir );
		ViewDirection.y = dot( Binormal, ViewDir );
		ViewDirection.z = dot( Normal, ViewDir );
		ViewDirection 	= normalize(ViewDirection);
	#endif

	#if defined(USE_SPECULARLIGHT0) ||  defined(USE_SPECULARLIGHT1) ||  defined(USE_RIMLIGHT)
		highp vec3 ViewDirec; 
		ViewDirec.x = dot( Tangent, ViewDir );
		ViewDirec.y = dot( Binormal, ViewDir );
		ViewDirec.z = dot( Normal, ViewDir );
		ViewDirec 	= normalize(ViewDirec);
	#endif
	
	#if defined(USE_BARLA) || defined(USE_VERTEXLIGHT) || defined(USE_SPECULARLIGHT) 
		highp vec3 LightDir = normalize(inPLightPos[0].xyz - vPos.xyz);
		LightDirection.x = dot( Tangent, LightDir );
		LightDirection.y = dot( Binormal, LightDir );
		LightDirection.z = dot( Normal, LightDir );
		LightDirection 	= normalize(LightDirection);
	#endif

	#if defined(USE_SPECULARLIGHT0) || defined(USE_SPECULARLIGHT1)
		H = normalize(LightDirection + ViewDirec);
	#endif

	#ifdef USE_RIMLIGHT
		lowp float NdotV 	 = 1.0 - dot( Normal, ViewDir );
		Rim	 = pow(NdotV , 5.0 * edgeGlossy) * edgeIntensity;
	#endif

	#ifdef USE_VERTEXLIGHT
		lowp vec4 VL = vec4(0.0,0.0,0.0,1.0);
		for(int i = 1; i <= 5; i++) {
			lowp float R 		= lightRadius[i-1];
			lowp float D 		= length(inPLightPos[i] - vPos.xyz);
			lowp float Att = 1.0 - clamp(D/R, 0.0, 1.0);
			
			lowp vec3 L  		= normalize(inPLightPos[i] - vPos.xyz);
			lowp float NdotL 	= pow(dot(Normal, L),0.45);
			NdotL 				= max(NdotL, 0.0) * Att;
			VL				  	= VL + (NdotL * vec4(lightDiffuse[i-1],1.0));
		}
		VXL = VL;
	#endif
	
	lowp float fogRatioY = 0.0;
	
	#if defined (USE_VFOG)
		fogRatioY = clamp(posW.z - inFogHeigh, 0.0, 1.0);
	#endif
	
#ifdef USE_FOG
	lowp float fog = clamp((gl_Position.z - inFogStart) * inFogRangeI, 0.0, 1.0);
	fogRatio = fog * inFogColor.a * (1.0 - fogRatioY);
#endif
		
	#ifdef COMPUTE_LINEAR_DEPTH
		highp vec4 posWS = (inWorldMatrix * vec4(inPos.xyz, 1.0));
		positionWorldSpace = posWS.xyz;
	#endif
}

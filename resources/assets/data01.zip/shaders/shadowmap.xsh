/*

This takes a light matrix and computes UV for parallel shadow map projection.

*/

void computeParallelLightProjection(
in highp mat4 lightMatrix, 				//the light matrix. Has to be parallel projection
in highp mat4 worldMatrix, 				//the object world matrix
in highp vec4 vtxPosition, 				//the vertex position in object space
out highp vec2 lightProjectedUV,		//the computed UV to sample in the shadow map
out highp float lightProjectedZ)		//the computed depth to compare with the shadow map value
{
	highp mat4 lm = lightMatrix * worldMatrix; //this is detected by the GPU and precomputed
	highp vec3 lightCoord  = (lm * vec4(inPos.xyz, 1.0)).xyz;

	lightProjectedUV = lightCoord.xy;
	lightProjectedZ = min(lightCoord.z + 0.0003, 1.0);
}
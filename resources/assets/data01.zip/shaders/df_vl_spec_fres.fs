varying lowp vec3 normal;
varying lowp vec3 lightDir;
varying lowp vec3 eyeDir;
varying highp vec2 uv;

uniform lowp float ColorScale;
uniform lowp float AlphaScale;
uniform lowp float ambIntns;
uniform lowp float SpecularIntensity;
uniform highp float Shininess;

#ifdef USE_FOG
uniform lowp vec4 fogColor;
varying lowp float fogFactor;
#endif

uniform sampler2D diffuseMap;

#ifdef COMPUTE_LINEAR_DEPTH
	varying highp vec3 positionWorldSpace;
	uniform highp vec4 inLinearDepthPlane;
#endif

void main()
{
	lowp vec4 diffuseCol = jetAlphaTexture2D(diffuseMap, uv);

	lowp vec3 n = normalize(normal);
	
	lowp float NdotL = dot(n, lightDir);
	lowp float diffuseIntensity = max(ambIntns, NdotL);
	
	lowp float specIntensity = 0.0;

#ifdef USE_SPEC	
	lowp float NdotH = 0.0;
	{
		lowp vec3 halfVec = normalize(eyeDir + lightDir);
		NdotH = max(dot(n, halfVec), 0.0);
		specIntensity = SpecularIntensity * pow(NdotH, Shininess);
	}
#endif //USE_SPEC	
	
	lowp vec3 color = diffuseCol.rgb * vec3((diffuseIntensity + specIntensity) * ColorScale);

#ifdef USE_FOG	
	color = mix(color, fogColor.rgb, fogFactor);
#endif
	
	lowp vec4 finalColor = vec4(color, diffuseCol.a * AlphaScale);
	
	#ifdef COMPUTE_LINEAR_DEPTH
		#define gl_FragColor gl_FragData[0]
	#endif

	gl_FragColor = finalColor;
	
	#if defined(COMPUTE_LINEAR_DEPTH)
		gl_FragData[1] = vec4(dot(vec4(positionWorldSpace.xyz, 1.0), inLinearDepthPlane));
	#endif
}

/*
----------------------------------------------------------
Ubershader usable parameters:
-----------------------------
Guide:
   + 	: optional parameter (the previous one should be added first). Only one of this optional params can be adde per each property.
   ++ 	: mandatory parameter (must be added if the previous one is added first). Only one of this optional params can be adde per each property.
   -or-	: exclusive parameter (if the element it's added noone of the similar/neighbour params can be added)
----------------------------------------------------------
	
USE_BARLA -> the diffuse-light calculation is done with a barla palette (Fx_BARLA_xxxxx.tga) 

USE_EMISSIVENESS -> the G channel of the MK texture is the mask for the emissiven (self illuminated) parts of the object

USE_SPECULARLIGHT -> adds specular light to the object
	++ USE_SPECULARLIGHT0 -> specPerLight (specular computed per light position + specularGlossiness)
	++ USE_SPECULARLIGHT1 -> specPalettePerLight (specular computed per light position + specularPalette [Fx_SPEC_xxxxx.tga])
	++ USE_SPECULARLIGHT2 -> specPerView (specular computed per camera + specularGlossiness)
	++ USE_SPECULARLIGHT3 -> specPalettePerView (specular computed per camera + specularPalette [Fx_SPEC_xxxxx.tga])

USE_LINEARSPACE -> corrects the SPECULAR calculation to linear-space (pow 0.45). the diffuse calculation si done with the barla palette, so it can be customized to emulate the gamma 2.2.
	
USE_RIMLIGHT -> adds per vertex rimlight.

USE_NDIS -> adds the NDIS texture as specular (thid means: additive over the diffuse). If there is specualr too, both are added.
 -or-
USE_NDISREFLECTION -> adds the NDIS texture as reflection (thid means: mix over the diffuse).
	+ USE_NDISALPHA -> adds (+) the NDIS.r channel to the DF alpha value. This makes the NDIS hilights opaque.
	+ USE_NDISGLASSEFFECT -> adds (+) the (NDIS.r * NDIS.g) to the DF alpha value. This makes the NDIS hilights opaque. 

USE_STAIN -> multiply a texture over the current final complete.
	
USE_ANIMATEDOVERLAY -> adds an animated overlay over the complete final color (the overlay is applied with additive blend).

USE_ANIMATEDTEXTURE -> all the 3 texture samplers (DF,NM,MK) are animated with offsets.

USE_VERTEXLIGHT -> use vertex lighting calculated with a maximum of 5 simultaneous lights. (The ligh is applied with additive)

USE_VERTEXDISTORTION -> shift the vertex positions using the vertex color as modulator.

----------------------------------------------------------
Define parameters:
----------------------------------------------------------
#define USE_VFOG 					//<-- optional for [USE_FOG]
#define USE_BARLA
#define USE_EMISSIVENESS
#define USE_SPECULARLIGHT
#define USE_SPECULARLIGHT0			//<-- mandatory for [USE_SPECULARLIGHT]
	//#define USE_SPECULARLIGHT1	//<-- mandatory for [USE_SPECULARLIGHT]
	//#define USE_SPECULARLIGHT2	//<-- mandatory for [USE_SPECULARLIGHT]
	//#define USE_SPECULARLIGHT3	//<-- mandatory for [USE_SPECULARLIGHT]	
#define USE_LINEARSPACE
#define USE_RIMLIGHT
#define USE_NDIS					//<-- exclusive between [USE_NDIS] & [USE_NDISREFLECTION]
	//#define USE_NDISREFLECTION	//<-- exclusive between [USE_NDIS] & [USE_NDISREFLECTION]	
	//#define USE_NDISALPHA			//<-- optional for [USE_NDIS] or [USE_NDISREFLECTION]	
	//#define USE_NDISGLASSEFFECT	//<-- optional for [USE_NDIS] or [USE_NDISREFLECTION]	
	//#define USE_ANIMATEDOVERLAY
	//#define USE_ANIMATEDTEXTURE
#define USE_STAIN
#define USE_VERTEXLIGHT
	//#define USE_VERTEXDISTORTION

*/
uniform 		sampler2D 	diffuseMap;
varying highp   vec2  		uv0;

#if defined(USE_BARLA) || defined(USE_SPECULARLIGHT) || defined(USE_NDIS) || defined(USE_NDISREFLECTION)
	uniform sampler2D normalMap;
#endif

#if defined(USE_STAIN)
	uniform  sampler2D 	stainMap;
#endif

#if defined(USE_NDIS) || defined(USE_NDISREFLECTION)
	uniform sampler2D ndisMap;
	uniform lowp float reflectionAmount;
	varying highp 	vec3  VSN;
#endif

#ifdef USE_FOG
	uniform lowp 	vec4 		inFogColor;
	varying lowp 	float 		fogRatio;
#endif

#if defined(USE_EMISSIVENESS) || defined(USE_SPECULARLIGHT) || defined(USE_RIMLIGHT) || defined(USE_NDIS) || defined(USE_NDISREFLECTION)
	uniform sampler2D maskMap;
#endif

#if defined(USE_ANIMATEDOVERLAY)
	uniform sampler2D overlayMap;
	varying highp	vec2 uvOverlay;
#endif

#ifdef USE_BARLA 
	uniform sampler2D barlaPalette;
	uniform lowp float diffuseIntensity;
	uniform lowp vec3 inPLightAM[8];
	varying lowp vec3  LightDirection;
#endif

#if defined(USE_SPECULARLIGHT)
	uniform mediump float specularIntensity;
	uniform mediump vec3 inPLightDF[8];
#endif

#if defined(USE_SPECULARLIGHT2) || defined(USE_SPECULARLIGHT3)
	varying lowp vec3  ViewDirection;
#endif

#if defined(USE_SPECULARLIGHT0) || defined(USE_SPECULARLIGHT2)
	uniform mediump float specularGlossy;
#endif

#if defined(USE_SPECULARLIGHT0) || defined(USE_SPECULARLIGHT1)
	varying lowp vec3  H;
#endif

#if defined(USE_SPECULARLIGHT1) || defined(USE_SPECULARLIGHT3)
	uniform sampler2D specularPalette;
#endif				

#ifdef USE_VERTEXLIGHT
	varying lowp vec4  VXL;
#endif

#if defined(USE_RIMLIGHT)
	varying lowp float   Rim;
#endif

#ifdef COMPUTE_LINEAR_DEPTH
	varying highp vec3 positionWorldSpace;
	uniform highp vec4 inLinearDepthPlane;
#endif

void main()
{
	lowp vec4 DF = jetAlphaTexture2D(diffuseMap, uv0);

	#if defined(USE_BARLA) || defined(USE_SPECULARLIGHT) || defined(USE_NDIS) || defined(USE_NDISREFLECTION)
		lowp vec4 NM = texture2D(normalMap , uv0) * 2.0 - 1.0;
	#endif

	#if defined(USE_EMISSIVENESS) || defined(USE_SPECULARLIGHT) || defined(USE_RIMLIGHT) || defined(USE_NDIS) || defined(USE_NDISREFLECTION)
		lowp vec4 MK = texture2D(maskMap, uv0);
	#endif
	
	#ifdef USE_BARLA
		lowp vec3 LDir 		= normalize(LightDirection);
		lowp float NdotL 	= (dot(NM.xyz, LDir) + 1.0) * 0.5;				
		lowp vec4 DFL 	= texture2D(barlaPalette , vec2(NdotL, 0.5)) * diffuseIntensity + vec4(inPLightAM[0],1.0);
	#endif
	
	#if defined(USE_EMISSIVENESS) && defined(USE_BARLA)
		DFL = mix(DFL, vec4(1.0), MK.g);
	#endif
	
	#if defined(USE_SPECULARLIGHT0) // 0 = specPerLight
		lowp float NdotH 	= max(dot(NM.rgb, normalize(H)), 0.0);
		#ifdef USE_LINEARSPACE 
			//liniar space correction 
			NdotH = pow(NdotH, 0.45); 
		#endif
		lowp vec4 SP  		= vec4(inPLightDF[0],1.0) * pow(NdotH,specularGlossy * 50.0) * specularIntensity * MK.r;
	#endif
	
	#if defined(USE_SPECULARLIGHT1) // 1 = specPalettePerLight
		lowp float NdotH 	= dot(NM.rgb, normalize(H));
		lowp vec4 SP		= texture2D(specularPalette , vec2(NdotH, 0.5));
		SP					= SP * vec4(inPLightDF[0], 1.0) * specularIntensity * MK.r;
	#endif
	
	#if defined(USE_SPECULARLIGHT2) // 2 = specPerView
		lowp vec3 VDir 		= normalize(ViewDirection);
		lowp float NdotV	= dot(NM.rgb, VDir);
		NdotV = max(NdotV,0.0);
		#ifdef USE_LINEARSPACE 
			//liniar space correction 
			NdotV = pow(NdotV, 0.45); 
		#endif
		lowp vec4 SP  		= vec4(inPLightDF[0],1.0) * pow(NdotV,specularGlossy * 50.0) * specularIntensity * MK.r;
	#endif
	
	#if defined(USE_SPECULARLIGHT3) // 3 = specPalettePerView
		lowp vec3 VDir 		= normalize(ViewDirection);
		lowp float NdotV 	= dot(NM.rgb, VDir);
		lowp vec4 SP		= texture2D(specularPalette , vec2(NdotV, 0.5));
		SP					= SP * vec4(inPLightDF[0], 1.0) * specularIntensity * MK.r;
	#endif
	
	#ifdef USE_RIMLIGHT
		#ifdef USE_BARLA
			lowp vec4 Rimlight = DFL * Rim * (1.0 - MK.r);	
		#else
			lowp vec4 Rimlight = vec4(Rim) * (1.0 - MK.r);	
		#endif	
	#endif
	
	#if defined(USE_NDIS) || defined(USE_NDISREFLECTION)
		lowp vec2 NDISuv = vec2((NM.x + VSN.x),(NM.y - VSN.y));
		lowp vec4 NDIS = texture2D(ndisMap, NDISuv.xy);
	#endif
	
	#if defined(USE_NDISREFLECTION)
		DF = mix(DF,NDIS, reflectionAmount * MK.r);
	#endif

	//COMPLETE					
	lowp vec4 Complete = DF;
	
	#ifdef USE_BARLA
		Complete *= DFL;
	#endif
	
	#if defined(USE_SPECULARLIGHT)
		Complete += SP;
	#endif
	
	#if defined(USE_NDIS)
		Complete += (NDIS * reflectionAmount * MK.r);
	#endif
	
	#ifdef USE_RIMLIGHT
		Complete += Rimlight;					
	#endif
	
	#ifdef USE_VERTEXLIGHT
		Complete += VXL;					
	#endif
	
	#if defined(USE_ANIMATEDOVERLAY)
		lowp vec4 OL		= texture2D(overlayMap , uvOverlay);
		Complete += OL;	
	#endif
	
	#if defined(USE_STAIN)
		lowp vec4 stain		= texture2D(stainMap , uv0);
		Complete = Complete * stain;
	#endif
	
#ifdef USE_FOG
	Complete = mix(Complete, inFogColor, fogRatio);
#endif

	#ifdef COMPUTE_LINEAR_DEPTH
		#define gl_FragColor gl_FragData[0]
	#endif		
	
	#if defined(USE_NDISGLASSEFFECT) || defined(USE_NDISALPHA)
		#ifdef USE_NDISGLASSEFFECT
			lowp float Alpha = (DF.a + NDIS.r * NDIS.g);
			gl_FragColor = vec4(Complete.rgb,Alpha);
		#endif
		#ifdef USE_NDISALPHA
			lowp float Alpha = (DF.a + NDIS.r);
			gl_FragColor = vec4(Complete.rgb,Alpha);
		#endif
	#else
			gl_FragColor = vec4(Complete.rgb,DF.a);
	#endif
	
	#if defined(COMPUTE_LINEAR_DEPTH)
		gl_FragData[1] = vec4(dot(vec4(positionWorldSpace.xyz, 1.0), inLinearDepthPlane));
	#endif
}
